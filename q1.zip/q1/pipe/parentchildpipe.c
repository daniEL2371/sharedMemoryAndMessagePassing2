#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>

int buf;
int main() {
	pid_t pid;
	
	int fd[2];
	pipe(fd);
	pid  = fork();
	if (pid == 0) {
		int readBuf;
		read(fd[0], &readBuf, sizeof(int));
		printf("Child: Current value of buf is %d\n", readBuf);
		readBuf = readBuf + readBuf;
		buf = readBuf;
		write(fd[1], &buf, sizeof(int));
		printf("Child: Current value of buf is %d\n", buf);
		//exit(0);
	} else {
		int status;
		int buf = 2;
		write(fd[1], &buf, sizeof(int));
		wait(&status);
		//printf("daub");
		int readBuf2;
		read(fd[0], &readBuf2, sizeof(int));
		printf("Parent: updated value of bud is: %d\n", readBuf2);
	}
	//printf("done\n");
}
