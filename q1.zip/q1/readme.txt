Author daniel zelalem
id     atr/2026/08
sec 	01
dep 	SE