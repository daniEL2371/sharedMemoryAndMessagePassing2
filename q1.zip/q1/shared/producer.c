#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>
#define N 5
#define True 1

int item = 0;
int *buf;
int main() {
	key_t key, key1, key2;
	key = 7000;
	key1 = 7001;
	key2 = 7002;
	int shmid = shmget(key,sizeof(int) * 5, IPC_CREAT | 0660);
	if (shmid < 0) {
		printf("Error has ocuured to aquire shared value\n");
	}
	
	buf = shmat(shmid, NULL, 0);
	if (buf ==  (void *) -1) {
		printf("Error has occured to attach to shared value\n");
		//shmctl(shmid, IPC_RMID, 0);
		return -1;
	}

	int shm_in = shmget(key1,sizeof(int), IPC_CREAT | 0660);
	if (shm_in < 0) {
		printf("Error has ocuured to aquire shared value\n");
	}
	
	int *ptr_in = shmat(shm_in, NULL, 0);
	if (ptr_in ==  (void *) -1) {
		printf("Error has occured to attach to shared value\n");
		//shmctl(shmid, IPC_RMID, 0);
		return -1;
	}
	
	
	int shm_out = shmget(key2,sizeof(int), IPC_CREAT | 0660);
	if (shmid < 0) {
		printf("Error has ocuured to aquire shared value\n");
	}
	
	
	int *ptr_out = shmat(shm_out, NULL, 0);
	if (ptr_out==  (void *) -1) {
		printf("Error has occured to attach to shared value\n");
		//shmctl(shmid, IPC_RMID, 0);
		return -1;
	}
	//ptr = buf;
	*ptr_out = 0;
	*ptr_in = 0;
	while(True) {
		while (((*ptr_in + 1) % N ) == *ptr_out);
		sleep(1);

		*(buf + *ptr_in) = item;
		printf("producer produces item: %d\n", item);
		*ptr_in = (*ptr_in + 1) % N ;
		item++;
	}

	
	shmdt(buf);
	shmdt(ptr_in);
	shmdt(ptr_out);
	shmctl(shmid, IPC_RMID, 0);
	shmctl(shm_in, IPC_RMID, 0);
	shmctl(shm_out, IPC_RMID, 0);
	return 1;
}
